import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JFrame;

public class FlowerTile extends PictureTile {
	
	private Image image;
	
	public FlowerTile(String name) {
		super(name);
		this.setToolTipText("FlowerTile");
		//System.out.println("In FlowerTile constructor");
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		String temp = this.getName();
		URL url;
		switch (temp) {
		case "Chrysanthemum":
			url = Bamboo1Tile.class.getResource("images/Chrysanthemum.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Orchid":
			url = Bamboo1Tile.class.getResource("images/Orchid.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Plum":
			url = Bamboo1Tile.class.getResource("images/Plum.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Bamboo":
			url = Bamboo1Tile.class.getResource("images/Bamboo.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		}
		
		g.drawImage(image, 19, 4, 53, 54, this);	
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Flower Tiles");

		frame.add(new FlowerTile("Chrysanthemum"));
		frame.add(new FlowerTile("Orchid"));
		frame.add(new FlowerTile("Plum"));
		frame.add(new FlowerTile("Bamboo"));

		frame.pack();
		frame.setVisible(true);
	}

	
}
