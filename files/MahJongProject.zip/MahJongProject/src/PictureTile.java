import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JFrame;

abstract public class PictureTile extends Tile {
	
	private String name;
	private Image image;
	
	public PictureTile(String name) {
		this.name = name;
		this.setToolTipText("PictureTile");
		//System.out.println("In PictureTile constructor");
	}
	
	public String toString() {
		return name;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		URL url;
		switch (this.name) {
		case "Sparrow":
			url = Bamboo1Tile.class.getResource("images/Sparrow.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Chrysanthemum":
			url = Bamboo1Tile.class.getResource("images/Chrysanthemum.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Orchid":
			url = Bamboo1Tile.class.getResource("images/Orchid.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Plum":
			url = Bamboo1Tile.class.getResource("images/Plum.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Bamboo":
			url = Bamboo1Tile.class.getResource("images/Bamboo.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Spring":
			url = Bamboo1Tile.class.getResource("images/Spring.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Summer":
			url = Bamboo1Tile.class.getResource("images/Summer.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Fall":
			url = Bamboo1Tile.class.getResource("images/Fall.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Winter":
			url = Bamboo1Tile.class.getResource("images/Winter.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		}
		g.drawImage(image, 19, 4, 53, 54, this);		
	}
	
	
	public static void main(String[] args) {
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Picture Tiles");

		frame.add(new Bamboo1Tile());

		frame.add(new FlowerTile("Chrysanthemum"));
		frame.add(new FlowerTile("Orchid"));
		frame.add(new FlowerTile("Plum"));
		frame.add(new FlowerTile("Bamboo"));

		frame.add(new SeasonTile("Spring"));
		frame.add(new SeasonTile("Summer"));
		frame.add(new SeasonTile("Fall"));
		frame.add(new SeasonTile("Winter"));

		frame.pack();
		frame.setVisible(true);
	}

	
}
