import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class CharacterTile extends Tile {
	
	protected char symbol;
	
	public CharacterTile(char symbol) {
		super();
		this.symbol = symbol;
		this.setToolTipText("CharacterTile");
		//System.out.println("In CharacterTile constructor");
	}
	
	public boolean matches(Tile other) {
		
		if (super.matches(other)) {
			
			CharacterTile otherObject = (CharacterTile)other;
			
			if (this.symbol == otherObject.symbol) {
				return true;
			}
		}

		return false;
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Font f2_0 = g.getFont();
		f2_0 = f2_0.deriveFont(f2_0.getSize2D() * 2.0F); // enlarge font
		
		Font f0_5 = g.getFont();
		f0_5 = f0_5.deriveFont(f0_5.getSize2D() * 0.5F); // enlarge font
		
		Font f2_75 = g.getFont();
		f2_75 = f2_75.deriveFont(f2_75.getSize2D() * 2.75F); // enlarge font
		
		Font f1_0 = g.getFont();
		f1_0 = f1_0.deriveFont(f1_0.getSize2D() * 1.0F); // enlarge font
		
		FontMetrics fm = g.getFontMetrics();
		String temp = "";
		int wid = 0;
		
		
		g.setColor(Color.BLACK);
		g.setFont(f2_0);													//font 2.0 black
		
		switch (this.symbol) {
		case '1' :	
			temp = Character.toString('\u4E00');
			break;
		case '2' :
			temp = Character.toString('\u4E8C');
			break;
		case '3' :
			temp = Character.toString('\u4E09');
			break;
		case '4' :
			temp = Character.toString('\u56DB');
			break;
		case '5' :
			temp = Character.toString('\u4E94');
			break;
		case '6' :
			temp = Character.toString('\u516D');
			break;
		case '7' :
			temp = Character.toString('\u4E03');
			break;
		case '8' :
			temp = Character.toString('\u516B');
			break;
		case '9' :
			temp = Character.toString('\u4E5D');
			break;
		case 'N' :
			temp = Character.toString('\u5317');
			break;
		case 'E' :
			temp = Character.toString('\u6771');
			break;
		case 'S' :
			temp = Character.toString('\u5357');
			break;
		case 'W' :
			g.setColor(Color.BLACK);
			temp = Character.toString('\u897F');
			break;
		case 'C' :
			g.setColor(Color.RED);
			temp = Character.toString('\u4E2D');
			break;
		case 'F' :
			g.setColor(Color.GREEN);
			temp = Character.toString('\u767C');
			break;
		default :
			break;
		}
		
		wid = fm.stringWidth(temp);
		
		switch (this.symbol) {
		case 'N': case 'E': case 'W': case 'S': case 'C': case 'F':
			g.setFont(f2_75);																	//font 1.5
			g.drawString(temp, ((Tile.S9 - wid) / 2) - (S1/2), Tile.S5);									//draw large character
		}
		
		switch (this.symbol) {
		case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
			g.drawString(temp, ((Tile.S10 - wid) / 2) - S1, Tile.S3 - Tile.S1);					//draw black character for 1-9
			g.setColor(Color.RED);
			g.setFont(f2_0);																	//font 2.0 red
			temp = Character.toString('\u842C'); //'wan' character
			wid = fm.stringWidth(temp);
			g.drawString(temp, ((Tile.S10 - wid) / 2) - S1, Tile.S6 - 1);							//draw red "wan"
		case 'N': case 'E': case 'W': case 'S': case 'C': case 'F':
			g.setColor(Color.RED);
			g.setFont(f1_0);																	//font 0.5 red
			g.drawString(Character.toString(this.symbol), (Tile.S6 + (Tile.S2 / 2)), Tile.S2);	//draw red char
		}
	}

	public String toString() {
		
		switch (this.symbol) {
		case '1' :
			return "Character 1";
		case '2' :
			return "Character 2";
		case '3' :
			return "Character 3";
		case '4' :
			return "Character 4";
		case '5' :
			return "Character 5";
		case '6' :
			return "Character 6";
		case '7' :
			return "Character 7";
		case '8' :
			return "Character 8";
		case '9' :
			return "Character 9";
		case 'N' :
			return "North Wind";
		case 'E' :
			return "East Wind";
		case 'S' :
			return "South Wind";
		case 'W' :
			return "West Wind";
		case 'C' :
			return "Red Dragon";
		case 'F' :
			return "Green Dragon";
		default :
			return "Error! - in CharacterTile";
		}
	}
	
	public static void main(String[] args) {
		
		JFrame		frame = new JFrame();
		JPanel		tiles = new JPanel();
		JScrollPane	scroller = new JScrollPane(tiles);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Character Tiles");
		frame.add(scroller);

		// Try something like this if your tiles don't fit on the screen.
		// Replace "tile width" and "tile height" with your values.
		//scroller.setPreferredSize(new Dimension(8 * tile width, 40 + tile height));

		tiles.add(new CharacterTile('1'));
		tiles.add(new CharacterTile('2'));
		tiles.add(new CharacterTile('3'));
		tiles.add(new CharacterTile('4'));
		tiles.add(new CharacterTile('5'));
		tiles.add(new CharacterTile('6'));
		tiles.add(new CharacterTile('7'));
		tiles.add(new CharacterTile('8'));
		tiles.add(new CharacterTile('9'));
		tiles.add(new CharacterTile('N'));
		tiles.add(new CharacterTile('E'));
		tiles.add(new CharacterTile('W'));
		tiles.add(new CharacterTile('S'));
		tiles.add(new CharacterTile('C'));
		tiles.add(new CharacterTile('F'));

		frame.pack();
		frame.setVisible(true);

	}
	
}
