import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JFrame;

public class Bamboo1Tile extends PictureTile {
	
	private static Image image;
	
	public Bamboo1Tile() {
		super("Sparrow");
		this.setToolTipText("Bamboo1Tile");
		//System.out.println("In Bamboo1Tile constructor");
	}

	public String toString() {
		return "Bamboo 1";
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		URL	url = Bamboo1Tile.class.getResource("images/Sparrow.png");
		image = Toolkit.getDefaultToolkit().getImage(url);
		g.drawImage(image, 19, 4, 53, 54, this);
		}

	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Bamboo 1 Tile");

		frame.add(new Bamboo1Tile());

		frame.pack();
		frame.setVisible(true);
	}

	
}
