import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Tile extends JPanel {
	
	public static final int SIDELENGTH = 60;						//200	60
	
	public static final int S1 = SIDELENGTH / 8;					//25	7.5
	public static final int S2 = SIDELENGTH / 4;					//50	15
	public static final int S3 = SIDELENGTH / 2;					//100	30
	public static final int S4 = S3 + S1;							//125	37.5
	public static final int S5 = S2 + S3;							//150	45
	public static final int S6 = S5 + S1;							//175	52.5
	public static final int S7 = SIDELENGTH;						//200	60
	public static final int S8 = SIDELENGTH + S1;					//225	67.5
	public static final int S9 = SIDELENGTH + S2;					//250	75
	public static final int S10 = S7 + S3;							//300	90
	public static final int S11 = S7 + S5;							//350	105
	
	//creating variables for easy sizing
	
	public static final Dimension SIZE = new Dimension(S9, S9);
	public static final Polygon SIDETOP;
	public static final Polygon SIDEBOTTOM;
	public static final Polygon BOTTOMTOP;
	public static final Polygon BOTTOMBOTTOM;
	public static final Polygon SHADOW;
	
	public static final Polygon FACE;
	public static GradientPaint grad0;
	public static GradientPaint grad1;
	public static GradientPaint grad2;
	public static GradientPaint grad3;
	public static GradientPaint grad4;
	
	public int x = 0;
	public int y = 0;
	public int z = 0;
	public boolean isSelected = false;
	
	//public static class MyTile extends JPanel {
		public Tile() {
			super();
			this.setPreferredSize(SIZE);
			this.setSize(SIZE);			//added this line for the MahjongModel for layout manager
			this.setOpaque(false);		//in case there is a white space around tile, this makes lower tiles show through
			this.setToolTipText("Tile");
			//System.out.println("In Tile constructor");
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			Graphics2D g2 = (Graphics2D) g;
			
			if(isSelected == false) {
				g2.setPaint(grad0);
			} else {
				g.setColor(Color.DARK_GRAY);
	        }

			g2.fill(FACE);
			g2.setPaint(grad0);
			
			g2.setPaint(grad1);
			g2.fill(SIDETOP);
			g2.setPaint(grad2);
			g2.fill(BOTTOMTOP);
			
			g2.setPaint(grad3);
			g2.fill(SIDEBOTTOM);
			
			g2.setPaint(grad4);
			g2.fill(BOTTOMBOTTOM);
			
//			Graphics2D g2s = (Graphics2D) g;
//			g2s.setColor(Color.BLACK);
//			Composite cOld = g2s.getComposite();
//			Composite cNew = ((AlphaComposite) cOld).derive(0.25F);
//			g2s.setComposite(cNew);
//			g.setClip(SHADOW);
//			g.fillPolygon(SHADOW);
//			g2s.setComposite(cOld);
			
		}
	
	static {
//		int[] x = {0, -S1, -S1, S6, S7, 0};
//		int[] y = {S2, S3-1, S9+S1, S9+S1, S9, S9};		
		int[] x = {0,S1,S10-S1,S10-S1,S9-1,S9-1,S7};
		int[] y = {S9,S10-S1,S10-S1,S1+1,0,S7,S9};
//		SHADOW = new Polygon(x, y, 6);
		SHADOW = new Polygon(x, y, 7);
		
		int[] stx = {S1, S1, S2, S2};
		int[] sty = {S1, S8, S7, 0};
		SIDETOP = new Polygon(stx, sty, 4);
		
		int[] sbx = {0, 0, S1, S1};
		int[] sby = {S2, S9, S8, S1};
		SIDEBOTTOM = new Polygon(sbx, sby, 4);
		
		int[] btx = {S1 , S8, S9, S2};
		int[] bty = {S8, S8, S7, S7};
		BOTTOMTOP = new Polygon(btx, bty, 4);
		
		int[] bbx = {0, S7, S8, S1};
		int[] bby = {S9, S9, S8, S8};
		BOTTOMBOTTOM = new Polygon(bbx, bby, 4);
		
		Color brown = new Color(165,42,42);
		grad0 = new GradientPaint(S2, 0, Color.WHITE, S11, S10, brown);
		FACE = new Polygon();
		FACE.addPoint(S2, 0);
		FACE.addPoint(S2, S7);
		FACE.addPoint(S9 - 1, S7);
		FACE.addPoint(S9 - 1, 0);
		
		grad1 = new GradientPaint(S2 / 2, S1 / 2, Color.WHITE, S2 / 2, S11, brown);
		grad2 = new GradientPaint(S5, S6, brown, S5, S9, Color.WHITE);
		grad3 = new GradientPaint(S1, S4, Color.WHITE, 0, S4, Color.BLUE);
		grad4 = new GradientPaint(S4, S8, Color.WHITE, S4, S9, Color.BLUE);
	}
	
	public boolean matches(Tile other) {
		if (other == null) {
			return false;
		}
		
		if (this.getClass() == other.getClass()) {
			return true;
		}
		
		return false;
	}
	
	public void setXYZ(int x, int y, int z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public static void main(String[] args) {
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Tile");

		frame.add(new Tile());

		frame.pack();
		frame.setVisible(true);
	}	
}