import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;

import javax.swing.JFrame;

public class CircleTile extends RankTile {
	
	public CircleTile(int rank) {
		super(rank);
		this.setToolTipText("CircleTile");
		//System.out.println("In CircleTile constructor");
	}
	
	class Circle extends CircleTile {
		
		public int x;
		public int y;
		public Color color;
		
		public Circle(int rank) {
			super(rank);
			this.setToolTipText("Circle");
			//System.out.println("In Circle constructor");
		}
		
		public void draw(int x, int y, Color color, Graphics g) {	
			this.x = x;
			this.y = y;
			this.color = color;
			
			int diameter = 0;
			if (this.rank == 1 || this.rank == 7 || this.rank == 8) {
				diameter = 12;
			} else if (this.rank == 2 || this.rank == 4) {
				diameter = 24;
			} else {
				diameter = 18;
			}

			final int DIAMETER = diameter;
			final int RADIUS = DIAMETER / 2;
			final int S = DIAMETER / 4;
			
			g.setColor(color);
			g.fillOval(x, y, DIAMETER, DIAMETER);
			g.setColor(Color.BLACK);
			g.drawLine(x + S, y + S, x + DIAMETER - S, y + DIAMETER - S); // draw \ in circle
			g.drawLine(x + DIAMETER - S, y + S, x + S, y + DIAMETER - S); // draw / in circle
			g.drawLine(x + RADIUS, y + S, x + RADIUS, y + DIAMETER - S); // draw | in circle
			g.drawLine(x + S, y + RADIUS, x + DIAMETER - S, y + RADIUS); // draw - in circle
		}

	}
	
	class Pancake extends CircleTile {

		public Pancake(int rank) {
			super(rank);
			this.setToolTipText("Pancake");
			//System.out.println("In Pancake constructor");
		}
		
		public void draw(Graphics g) {
			g.setColor(Color.BLUE);
			g.fillOval(20, 5, 49, 51); //outer blue ring
			g.setColor(Color.GREEN);
			g.fillOval(23, 8, 43, 45);//inner green circle
			g.setColor(Color.BLACK);
			g.drawOval(42, 13, 6, 6); //top
			g.drawOval(42, 44, 6, 6); //bottom
			g.drawOval(27, 29, 6, 6); //left
			g.drawOval(57, 29, 6, 6); //right
			
			g.drawOval(31, 18, 6, 6); //top left
			g.drawOval(31, 39, 6, 6); //bottom left
			g.drawOval(53, 18, 6, 6); //top right
			g.drawOval(53, 39, 6, 6); //bottom right
		}
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Circle c = new Circle(this.rank);
		Pancake p = new Pancake(this.rank);
		
		switch (this.rank) {
		case 1 :
			p.draw(g);
			c.draw(39,25,Color.RED, g);
			break;
		case 2 :
			c.draw(30,5,Color.GREEN, g);
			c.draw(30,32,Color.RED, g);
			break;
		case 3 :
			c.draw(17,2,Color.BLUE, g);
			c.draw(35,21,Color.RED, g);
			c.draw(53,40,Color.GREEN, g);
			break;
		case 4 :
			c.draw(19,5,Color.BLUE, g);
			c.draw(19,32,Color.GREEN, g);
			c.draw(47,5,Color.GREEN, g);
			c.draw(47,32,Color.BLUE, g);
			break;
		case 5 :
			c.draw(17,2,Color.BLUE, g);
			c.draw(35,22,Color.RED, g);
			c.draw(53,40,Color.BLUE, g);
			c.draw(17,40,Color.GREEN, g);
			c.draw(53, 2, Color.GREEN, g);
			break;
		case 6 :
			c.draw(24,2,Color.GREEN, g);
			c.draw(24,21,Color.RED, g);
			c.draw(24,40,Color.RED, g);
			c.draw(48,2,Color.GREEN, g);
			c.draw(48,21,Color.RED, g);
			c.draw(48,40,Color.RED, g);
			break;
		case 7 :
			c.draw(19,4,Color.GREEN, g);
			c.draw(38,8,Color.GREEN, g);
			c.draw(57,14,Color.GREEN, g);
			
			c.draw(24,29,Color.RED, g);
			c.draw(52,29,Color.RED, g);
			
			c.draw(24,42,Color.RED, g);
			c.draw(52,42,Color.RED, g);
			break;
		case 8 :
			c.draw(24,3,Color.BLUE, g);
			c.draw(52,3,Color.BLUE, g);
			
			c.draw(24,17,Color.BLUE, g);
			c.draw(52,17,Color.BLUE, g);
			
			c.draw(24,31,Color.BLUE, g);
			c.draw(52,31,Color.BLUE, g);
			
			c.draw(24,44,Color.BLUE, g);
			c.draw(52,44,Color.BLUE, g);
			
			break;
		case 9 :
			c.draw(16,2,Color.GREEN, g);
			c.draw(35,2,Color.GREEN, g);
			c.draw(54,2,Color.GREEN, g);
			c.draw(16,21,Color.RED, g);
			c.draw(35,21,Color.RED, g);
			c.draw(54,21,Color.RED, g);
			c.draw(16,40,Color.BLUE, g);
			c.draw(35,40,Color.BLUE, g);
			c.draw(54,40,Color.BLUE, g);
			break;
		default :
		}		
	}
	
	public String toString() {
		switch (this.rank) {
		case 1 :
			return "Circle 1";
		case 2 :
			return "Circle 2";
		case 3 :
			return "Circle 3";
		case 4 :
			return "Circle 4";
		case 5 :
			return "Circle 5";
		case 6 :
			return "Circle 6";
		case 7 :
			return "Circle 7";
		case 8 :
			return "Circle 8";
		case 9 :
			return "Circle 9";
		default :
			return "Error! - in CircleTile";
		}
	}
	
	public static void main(String[] args)	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Circle Tiles");

		frame.add(new CircleTile(1));
		frame.add(new CircleTile(2));
		frame.add(new CircleTile(3));
		frame.add(new CircleTile(4));
		frame.add(new CircleTile(5));
		frame.add(new CircleTile(6));
		frame.add(new CircleTile(7));
		frame.add(new CircleTile(8));
		frame.add(new CircleTile(9));

		frame.pack();
		frame.setVisible(true);
	}

	
}
