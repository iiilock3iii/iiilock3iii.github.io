import	java.util.*;
import	java.awt.*;
import	javax.swing.*;


public class ScrollPane extends JScrollPane {

	private	JPanel[]	discard = new JPanel[2];
	public	Stack<Tile>	undoStack = new Stack<Tile>();
	public	Stack<Tile>	redoStack = new Stack<Tile>();		
	private		int		width = 25;
	private		int		height = 55;
	private		int		count = 0;
	private int tileCount = 0;

	public ScrollPane() {
		
		setPreferredSize(new Dimension(0, 2 * height + 33));

		discard[0] = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		discard[1] = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		discard[0].setPreferredSize(new Dimension(0, height));
		discard[1].setPreferredSize(new Dimension(0, height));

		setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

		JPanel	panel = new JPanel(new BorderLayout());
		setViewportView(panel);

		panel.add(discard[0], BorderLayout.NORTH);
		panel.add(discard[1], BorderLayout.SOUTH);

		discard[0].setBackground(Color.LIGHT_GRAY);
		discard[1].setBackground(Color.LIGHT_GRAY);
		panel.setBackground(Color.BLACK);
	}


	public void addToUndo(Tile t1, Tile t2) {
		
		undoStack.push(t1);
		undoStack.push(t2);
		
		t1.setVisible(true);
		t2.setVisible(true);
		t1.isSelected = false;
		t2.isSelected = false;

		Dimension	size = new Dimension(++count * width, height + 6);
		discard[0].setPreferredSize(size);
		discard[1].setPreferredSize(size);

		discard[0].add(t1);
		discard[1].add(t2);

		Rectangle	r = new Rectangle(count * width, 0, width, height + 6);
		getViewport().scrollRectToVisible(r);
		
		tileCount += 2;
		
		revalidate();
		repaint();
	}

	public void discardAll() {
		
		undoStack.clear();	
		
		for(int i = 0; i < discard.length; i++) {
			discard[i].removeAll();
			discard[i].revalidate();
		}
		this.revalidate();
		tileCount = 0;
	}
	
	public void undoMove(Tile t1, Tile t2) {
		
		discard[0].remove((tileCount/2)-1);
		discard[0].revalidate();
		discard[1].remove((tileCount/2)-1);
		discard[1].revalidate();
		
		this.revalidate();
		tileCount -= 2;
	}
	
	
}

