
public class PlayMahJong {

	public static void main(String[] args) {
		new MahJongModel(0);
	}

}
