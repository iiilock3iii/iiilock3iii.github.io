import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;

import javax.swing.JFrame;

public class SeasonTile extends PictureTile {
	
	private Image image;
	
	public SeasonTile(String name) {
		super(name);
		this.setToolTipText("SeasonTile");
		//System.out.println("In SeasonTile constructor");
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		String temp = this.getName();
		URL url;
		switch (temp) {
		case "Spring":
			url = Bamboo1Tile.class.getResource("images/Spring.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Summer":
			url = Bamboo1Tile.class.getResource("images/Summer.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Fall":
			url = Bamboo1Tile.class.getResource("images/Fall.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		case "Winter":
			url = Bamboo1Tile.class.getResource("images/Winter.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			break;
		}
		
		g.drawImage(image, 19, 4, 53, 54, this);
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Season Tiles");

		frame.add(new SeasonTile("Spring"));
		frame.add(new SeasonTile("Summer"));
		frame.add(new SeasonTile("Fall"));
		frame.add(new SeasonTile("Winter"));

		frame.pack();
		frame.setVisible(true);
	}
}
