import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class MahJongTest extends JFrame
{

	public MahJongTest()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		add(new TestPanel());
		
		setSize(500, 500);

		setVisible(true);
	}
	
	public class TestPanel extends JPanel
	{
		public TestPanel()
		{
			setLayout(null); //must setSize in Tile
			
			Tile t;
			
			t = new SeasonTile("Spring");
			t.setLocation(200, 100);
			add(t);
			System.out.println(this.getComponentZOrder(t));
			
			t = new SeasonTile("Summer");
			t.setLocation(200 - Tile.S2, 100 + Tile.S2);
			add(t);
			System.out.println(this.getComponentZOrder(t));
			
			t = new SeasonTile("Fall");
			t.setLocation(200 - (Tile.S2*2), 100 + (Tile.S2*2));
			add(t);
			System.out.println(this.getComponentZOrder(t));
			
			t = new SeasonTile("Winter");
			t.setLocation(200 - (Tile.S2*3), 100 + (Tile.S2*3));
			add(t);
			System.out.println(this.getComponentZOrder(t));
			
			
			
			//walk through data structure in orderly fashion, keep in mind
			//the z-order. Start drawing from the top and then on next layer
			//down start drawing from bottom left going up the columns then
			//move right one and from bottom go up again
			
			//develop an algorithm for drawing the tiles, so you dont have to
			//draw 144 tiles
			
			/*Delroy's Location Algorithm:      //face is the height/width
			 * x = row * FACE +/- layer * EDGE  //edge is thickness of tile
			 * y = col * FACE +/- layer * EDGE
			 * setLocation(x,y);
			 * 
			 * for 4 odd tiles, have 3 separate if's for those cases
			 * also take into account for row '0' for the most left
			 * odd tile
			 * 
			 * 3 for loops, walking through the data structure
			 * 
			 * after removing a tile may need to use
			 * repaint();
			 * revalidate();
			 * 
			 * for the remove you will use getSource to get the tile that
			 * was clicked on, videos DieDemo 27min
			 * 
			 * to randomize tiles, look in Collections class in the util
			 * class, in Collections use the .shuffle method
			 * 
			 * create arraylist deck, loop 4 times and add all the tiles
			 * with deck.add
			 * then add the tiles that are only in once
			 * 
			 * then to deal out the tiles do a deal
			 * return deck.remove -1 to remove from the end of the deck
			 * 
			 * 
			 * 
			 */
			
		}
	}
	
	
	public static void main(String[] args)
	{
		new MahJongTest();
	}

}
