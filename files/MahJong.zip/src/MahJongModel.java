import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Polygon;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.URL;
import java.util.Stack;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;

public class MahJongModel extends JFrame implements ActionListener {
	
	public static GradientPaint grad;
	public static Polygon gradient;
												//[ROWS][COLS][LAYERS]
	public static Tile[][][] dataStructure = new Tile[9][16][5];
	public static int x;
	public static int y;
	
	Tile selected;
	ScrollPane pane = new ScrollPane();
	PlayClip playclip = new PlayClip("audio/stone-scraping.wav", true);

	public MahJongModel(int gameNumber) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		nullOutDataStructure();
		setSize(960, 725);
		addBottomScrollPane();
		makeMenu();
		add(new Board(gameNumber));
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String whichButtonPressed = e.getActionCommand();
		
		if (whichButtonPressed.equals("North")) {
			JOptionPane.showMessageDialog (null, "North",
					"Direction", JOptionPane.INFORMATION_MESSAGE);
		} else if (whichButtonPressed.equals("South")) {
			JOptionPane.showMessageDialog (null, "South",
					"Direction", JOptionPane.INFORMATION_MESSAGE);
		} else if (whichButtonPressed.equals("East")) {
			JOptionPane.showMessageDialog (null, "East",
					"Direction", JOptionPane.INFORMATION_MESSAGE);
		} else if (whichButtonPressed.equals("West")) {
			JOptionPane.showMessageDialog (null, "West",
					"Direction", JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
private void addBottomScrollPane() {
	this.setLayout(new BorderLayout());
    
//	pane.setPreferredSize(new Dimension(135,135));
	this.add(pane, BorderLayout.SOUTH);
}

private void makeMenu() {
	JMenuBar	menuBar = new JMenuBar();
	setJMenuBar(menuBar);

	JMenu	gameMenu = new JMenu("Game");
	gameMenu.setMnemonic('G');
	menuBar.add(gameMenu);
	
	JMenu	soundMenu = new JMenu("Sound");
	soundMenu.setMnemonic('S');
	menuBar.add(soundMenu);
	
	JMenu	moveMenu = new JMenu("Move");
	moveMenu.setMnemonic('M');
	menuBar.add(moveMenu);
	
	JMenu	helpMenu = new JMenu("Help");
	helpMenu.setMnemonic('H');
	menuBar.add(helpMenu);

	JMenuItem play = new JMenuItem("Play", 'P');
	play.setToolTipText("start a new game");
	play.setAccelerator(KeyStroke.getKeyStroke("ctrl P"));
	gameMenu.add(play);
	play.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Play", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});

	JMenuItem restart = new JMenuItem("Restart", 'R');
	restart.setToolTipText("restart the current game");
	restart.setAccelerator(KeyStroke.getKeyStroke("ctrl R"));
	gameMenu.add(restart);
	restart.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Restart", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
	
	JMenuItem numbered = new JMenuItem("Numbered", 'N');
	numbered.setToolTipText("play a numbered (and therefore a repeatable game)");
	numbered.setAccelerator(KeyStroke.getKeyStroke("ctrl N"));
	gameMenu.add(numbered);
	numbered.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Numbered", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
	
	JMenuItem tournament = new JMenuItem("Tournament*", 'T');
	tournament.setToolTipText("start a game in tournament mode");
	tournament.setAccelerator(KeyStroke.getKeyStroke("ctrl T"));
	gameMenu.add(tournament);
	tournament.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Tournament*", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
	
	JMenuItem soundOn = new JMenuItem("On", 'O');
	soundOn.setToolTipText("turn sound on");
	soundOn.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
	soundMenu.add(soundOn);
	soundOn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			sound(true);
		}
	});
	
	JMenuItem soundOff = new JMenuItem("Off", 'F');
	soundOff.setToolTipText("turn sound off");
	soundOff.setAccelerator(KeyStroke.getKeyStroke("ctrl F"));
	soundMenu.add(soundOff);
	soundOff.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			sound(false);
		}
	});
	
	JMenuItem undo = new JMenuItem("Undo", 'U');
	undo.setToolTipText("undo last move");
	undo.setAccelerator(KeyStroke.getKeyStroke("ctrl U"));
	moveMenu.add(undo);
	undo.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Undo", "Title",
					JOptionPane.INFORMATION_MESSAGE);
//			undoMove();
		}
	});
	
	JMenuItem redo = new JMenuItem("Redo", 'R');
	redo.setToolTipText("redo last move");
	redo.setAccelerator(KeyStroke.getKeyStroke("ctrl R"));
	moveMenu.add(redo);
	redo.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Redo", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
	
	JMenuItem operation = new JMenuItem("Operation", 'O');
	operation.setToolTipText("game operation");
	operation.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
	helpMenu.add(operation);
	operation.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Operation", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
	
	JMenuItem gameRules = new JMenuItem("Game Rules", 'G');
	gameRules.setToolTipText("undo last move");
	gameRules.setAccelerator(KeyStroke.getKeyStroke("ctrl G"));
	helpMenu.add(gameRules);
	gameRules.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog (null, "Game Rules", "Title",
					JOptionPane.INFORMATION_MESSAGE);
		}
	});
}
	
	public static void nullOutDataStructure() {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 15; j++) {
				for (int k = 0; k < 5; k++) {
					dataStructure[i][j][k] = null;
				}
			}
		}
	}
	
	public class Board extends JPanel implements MouseListener {
		
		private Image image;
		
		public Board(int gameNumber) {
			setLayout(null); //No default layout manager. Also must put a setSize in Tile class
			TileDeck t = new TileDeck(gameNumber);

			//layer 4----------------------------------------------------------------------------------
			//top tile
			dataStructure[4][6][4] = t.deal();		//deal out a tile, place it in the dataStructure
			dataStructure[4][6][4].setXYZ(4, 6, 4);	//store the x,y, and z of the tile in itself
			set(dataStructure[4][6][4],4,6,4,1,-1);	//call paint method to locate/paint tile
			//layer 3----------------------------------------------------------------------------------
			for (int i = 6; i < 8; i++) {
				for (int j = 4; j > 2; j--) {
					dataStructure[j][i][3] = t.deal();
					dataStructure[j][i][3].setXYZ(j, i, 3);
					set(dataStructure[j][i][3],j,i,3,1,-1);
				}
			}
			//layer 2----------------------------------------------------------------------------------
			for (int i = 5; i < 9; i++) {
				for (int j = 5; j > 1; j--) {
					dataStructure[j][i][2] = t.deal();
					dataStructure[j][i][2].setXYZ(j, i, 2);
					set(dataStructure[j][i][2],j,i,2,1,-1);
				}
			}
			//layer 1----------------------------------------------------------------------------------
			for (int i = 4; i < 10; i++) {
				for (int j = 6; j > 0; j--) {
					dataStructure[j][i][1] = t.deal();
					dataStructure[j][i][1].setXYZ(j, i, 1);
					set(dataStructure[j][i][1],j,i,1,1,-1);
				}
			}
			//layer 0----------------------------------------------------------------------------------
			//one left side special case tile
			dataStructure[4][0][0] = t.deal();
			dataStructure[4][0][0].setXYZ(4, 0, 0);
			set(dataStructure[4][0][0],4,0,0,1,1);
			//left zig-zag section of bottom layer
			int[] layer0section1 = {7,4,3,0};
			int[] layer0section2 = {7,5,4,3,2,0};
			for (int i = 0; i < 4; i++) {
				dataStructure[layer0section1[i]][1][0] = t.deal();
				dataStructure[layer0section1[i]][1][0].setXYZ(layer0section1[i], 1, 0);
				set(dataStructure[layer0section1[i]][1][0],layer0section1[i],1,0,1,1);
			}
			for (int i = 0; i < 6; i++) {
				dataStructure[layer0section2[i]][2][0] = t.deal();
				dataStructure[layer0section2[i]][2][0].setXYZ(layer0section2[i], 2, 0);
				set(dataStructure[layer0section2[i]][2][0],layer0section2[i],2,0,1,1);
			}
			//middle square section of bottom layer
			for (int i = 3; i < 11; i++) {
				for (int j = 7; j >= 0; j--) {
					dataStructure[j][i][0] = t.deal();
					dataStructure[j][i][0].setXYZ(j, i, 0);
					set(dataStructure[j][i][0],j,i,0,1,1);
				}
			}
			//right zig-zag section of bottom layer
			for (int i = 0; i < 6; i++) {
				dataStructure[layer0section2[i]][11][0] = t.deal();
				dataStructure[layer0section2[i]][11][0].setXYZ(layer0section2[i], 11, 0);
				set(dataStructure[layer0section2[i]][11][0],layer0section2[i],11,0,1,1);
			}
			for (int i = 0; i < 4; i++) {
				dataStructure[layer0section1[i]][12][0] = t.deal();
				dataStructure[layer0section1[i]][12][0].setXYZ(layer0section1[i], 12, 0);
				set(dataStructure[layer0section1[i]][12][0],layer0section1[i],12,0,1,1);
			}
			
			//two right side special case tiles
			dataStructure[4][13][0] = t.deal();
			dataStructure[4][13][0].setXYZ(4, 13, 0);
			set(dataStructure[4][13][0],4,13,0,1,1);
			
			dataStructure[4][14][0] = t.deal();
			dataStructure[4][14][0].setXYZ(4, 14, 0);
			set(dataStructure[4][14][0],4,14,0,1,1);
			
			//set background color of whole board
			Color darkRed = new Color(0x7A0000);
			this.setBackground(darkRed);
		}
		
		@Override
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			Graphics2D g2 = (Graphics2D) g;
			g2.setPaint(grad);
			g2.fill(gradient);
			
			URL	url = Bamboo1Tile.class.getResource("images/dragon_bg.png");
			image = Toolkit.getDefaultToolkit().getImage(url);
			g.drawImage(image, 100, 50, this);
			}
		
		/**
		 * Method so set the tile logically in the data structure
		 * @param t the incoming tile
		 * @param row the row of the data structure
		 * @param col the column of the data structure
		 * @param layer the layer of the data structure (z order)
		 * @param xSign offset for x: -1 is negative offset, 1 is positive offset
		 * @param ySign offset for y: -1 is negative offset, 1 is positive offset
		 */
		public void set(Tile t, int row, int col, int layer, int xSign, int ySign) {
			//for x and y sign: -1 is minus 1 is plus
			if (xSign == 1) {
				x = (col * Tile.SIDELENGTH) + (layer * Tile.S2);
			} else if (xSign == -1) {
				x = (col * Tile.SIDELENGTH) - (layer * Tile.S2);
			}
			if (ySign == 1) {
				y = (row * Tile.SIDELENGTH) + (layer * Tile.S2);
			} else if (ySign == -1) {
				y = (row * Tile.SIDELENGTH) - (layer * Tile.S2);
			}
			//for the three special case bottom layer tiles, 1 on left and 2 on right
			if ((row == 4 && col == 0 || col == 13 || col == 14)) {
				y -= 30; //scoot the tile up half of a tile
			}
			//for the special case top tile
			if (row == 4 && col == 6 && layer == 4) {
				y -= 30; //scoot tile up half of a tile
				x += 30; //scoot tile right half of a tile
			}
			x+= 15;  //move all tiles down and to the right a bit
			y+= 15;
			t.setLocation(x,y);
			t.addMouseListener(this);
			add(t);
		}
		
		public void mousePressed(MouseEvent e) {
			Tile tile = (Tile)e.getSource();

			System.out.println("\nParent: " + tile.getParent());
			System.out.println("Z-Order: " + tile.getParent().getComponentZOrder(tile));
			System.out.println("x:" + tile.x + " y:" + tile.y + " z:" + tile.z);
			System.out.println("Tile is open: " + isTileOpen(tile));
			
			System.out.println("Tile at [" + tile.x + "][" + tile.y + "][" + tile.z +
					"] is " + dataStructure[tile.x][tile.y][tile.z]);

			if (e.getButton() == MouseEvent.BUTTON1) {
				if (isTileOpen(tile)) {
					System.out.println("selected: " + selected);
					if (selected != null) {
						System.out.println("selected matches tile: " + selected.matches(tile));	
					}
					if (selected == null) {
						selected = tile;
						selected.isSelected = true;
						selected.repaint();
						System.out.println("HERE1, selected:" + selected);
						System.out.println("HERE1, tile:" + tile);
						System.out.println("1Tile at [" + tile.x + "][" + tile.y + "][" + tile.z +
								"] is " + dataStructure[tile.x][tile.y][tile.z]);
					} else if (selected != null && selected.matches(tile)
							&& !(selected.x == tile.x && selected.y == tile.y && selected.z == tile.z)) {
						System.out.println("HERE2, selected:" + selected);
						System.out.println("HERE2, tile:" + tile);
						System.out.println("2selected at [" + selected.x + "][" + selected.y + "][" + selected.z +
								"] is " + dataStructure[selected.x][selected.y][selected.z]);
						System.out.println("2Tile at [" + tile.x + "][" + tile.y + "][" + tile.z +
								"] is " + dataStructure[tile.x][tile.y][tile.z]);
						selected.removeMouseListener(this);
						tile.removeMouseListener(this);
						pane.addToUndo(selected, tile);
//************for next lab will add a 'stack' here to add tiles to so they are not really removed
						dataStructure[selected.x][selected.y][selected.z] = null;
						dataStructure[tile.x][tile.y][tile.z] = null;
						this.remove(selected);
						this.remove(tile);
						selected = null;
						playclip.play();
						selected = null;
						if(pane.undoStack.size() == 144) {
							runFireworks();
						}
					} else if (selected != null && !selected.matches(tile)) {
						System.out.println("SELECTED not null and doesnt match tile");
						selected.isSelected = false;
						selected.repaint();
						selected = null;
					} else {
						System.out.println("HERE*******************");
						System.out.println("HERE, selected:" + selected);
						System.out.println("HERE, tile:" + tile);
						System.out.println("Selected at [" + selected.x + "][" + selected.y + "][" + selected.z +
								"] is " + dataStructure[selected.x][selected.y][selected.z]);
						System.out.println("Tile at [" + tile.x + "][" + tile.y + "][" + tile.z +
								"] is " + dataStructure[tile.x][tile.y][tile.z]);
					}
					revalidate();
					repaint();
				}
				
			}
			System.out.println("Tile at [" + tile.x + "][" + tile.y + "][" + tile.z +
					"] is " + dataStructure[tile.x][tile.y][tile.z]);
		}
		
		public void mouseReleased(MouseEvent e) {}
		public void mouseClicked(MouseEvent e) {}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
	}

	public boolean isTileOpen(Tile t) {
//		System.out.println("x:" + t.x + " y:" + t.y + " z:" + t.z);
		if (t.z == 4) {
			return true; //top tile, always open
		}
		if (t.y == 14) {
			return true; //far rightmost tile, always open
		}
		if (t.y == 0) {
			return true; //far leftmost tile, always open
		}
		if (t.z == 3 && (dataStructure[4][6][4] != null)) {
			return false; //if picking tile on layer 3 and the top tile is still in play, return false
		}
		if ((dataStructure[t.x][t.y][t.z + 1] == null) && (dataStructure[t.x][t.y - 1][t.z] == null || dataStructure[t.x][t.y + 1][t.z] == null)) {
			return true;
		}
		return false;
	}
	
	public void undoMove() {
    	
    	if(!pane.undoStack.empty()) {
	    	// pop last two tiles from scrollpane's stack
	    	Tile temp1 = pane.undoStack.pop();
	    	Tile temp2 = pane.undoStack.pop();
	    	
	    	// push into redoStack
//	    	pane.redoStack.push(temp1);
//	    	pane.redoStack.push(temp2);
	    	
	    	// link to new method to revalidate scrollpane here
	    	pane.undoMove(temp1, temp2);
	    	
	    	// enable visible for last two removed tiles
	    	
    	} 
    	else {
    		System.out.println("Nothing to Undo");	
    	}
    }
	
	public void runFireworks() {
		
		JFrame		frame = new JFrame();
		Fireworks	fw = new Fireworks();
		
		frame.setSize(1000, 800);
		frame.add(fw.getPanel());
		frame.setVisible(true);

		fw.setExplosions(0, 1000);
		fw.fire();

		try {
			Thread.sleep(10000);
			fw.stop();
		}
		catch (InterruptedException ie) {}
	}
	
    public void sound(boolean b) {

    	if(b == false){
    		playclip.sound = false;
    	} else {
    		playclip.sound = true;
    	}
    }
	
	static {
		int[] x = {11,11,932,932};
		int[] y = {11,515,515,11};
		gradient = new Polygon(x, y, 4);
		
		Color lightGray = new Color(0xD4D4D4);
		Color blueish = new Color(0x073EA6);
		
		grad = new GradientPaint(-150, -150, lightGray, 800, 800, blueish);
	}
	
	public static void main(String[] args) {
		new MahJongModel(0);
	}

}
