abstract public class RankTile extends Tile {
	
	protected int rank;
	
	public RankTile(int rank) {
		this.rank = rank;
	}
	
	public boolean matches(Tile other) {
		
		if (super.matches(other)) {
			
			RankTile otherObject = (RankTile)other;
			
			if (this.rank == otherObject.rank) {
				return true;
			}
		}

		return false;

	}
	
	public RankTile() {
		super();
		this.setToolTipText("Rank Tile");
		//System.out.println("In RankTile constructor");
	}
}
