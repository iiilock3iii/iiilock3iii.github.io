import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;

import javax.swing.JFrame;

public class WhiteDragonTile extends Tile {
	
	public WhiteDragonTile() {
		super();
		this.setToolTipText("WhiteDragonTile");
		//System.out.println("In WhiteDragonTile constructor");
	}
	
	public String toString() {
		return "White Dragon";
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.setColor(Color.BLUE);
		g.fillRect(21, 5, 8, 5);//top
		g.fillRect(37, 5, 8, 5);
		g.fillRect(53, 5, 8, 5);
		
		g.fillRect(21, 50, 8, 5);//bottom
		g.fillRect(37, 50, 8, 5);
		g.fillRect(53, 50, 8, 5);
		
		g.fillRect(21, 18, 5, 8);//left
		g.fillRect(21, 34, 5, 8);
		
		g.fillRect(64, 10, 5, 8);//right
		g.fillRect(64, 26, 5, 8);
		g.fillRect(64, 42, 5, 8);
		
		g.setColor(Color.BLACK);
		g.drawRect(20, 4, 49, 51);//outer square
		g.drawRect(26, 10, 37, 39);//inner square
		
		g.setColor(Color.WHITE);
		g.fillRect(29, 5, 8, 5);//top
		g.fillRect(45, 5, 8, 5);
		g.fillRect(61, 5, 8, 5);
		
		g.fillRect(29, 50, 8, 5);//bottom
		g.fillRect(45, 50, 8, 5);
		g.fillRect(61, 50, 8, 5);
		
		g.fillRect(21, 10, 5, 8);//left
		g.fillRect(21, 26, 5, 8);
		g.fillRect(21, 42, 5, 8);
		
		g.fillRect(64, 18, 5, 8);//right
		g.fillRect(64, 34, 5, 8);
	}
	
	public static void main(String[] args) {
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Circle Tiles");

		frame.add(new WhiteDragonTile());

		frame.pack();
		frame.setVisible(true);
	}
}
